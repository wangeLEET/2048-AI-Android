# 2048 AI 辅助器（Android 11+）

适用范围：标准 4×4 / 2 与 4 随机出现的 2048 规则，尤其是微信小程序中的常见 2048 实现。

这是**完整的 Android Studio Java 工程源代码**，不是已编译 APK。当前环境缺少 Android SDK/Gradle，因此没有声称打包或在手机上实际测试通过。工程中的纯 Java 合并规则与 Expectimax 决策模块已经通过本地 `javac` 自测。悬浮窗截图修复尚未在真实安卓设备上复测。

## 功能

- **实时识别**：在屏幕上框选 4×4 棋盘后，约每秒读取安卓无障碍截图；悬浮窗遮住棋盘时在截图前自动隐藏辅助层并等待界面刷新，截图后立即恢复；直接使用用户提供截图标定的方块颜色（0、2、4、8、16、32、64、128、256、512、1024、2048），无需 OCR 或外部运行库。
- **AI 推荐**：手机上运行 Expectimax，考虑出现 2/4 的概率、空位、大数字角落、单调性及相邻方块合并机会。
- **单步**：按一下，执行一个当前推荐的方向。
- **自动**：自动识别、计算、滑动，并检查每一步滑动后的棋盘是否等于“理论移动结果 + 恰好一个随机新方块”。
- **防误触**：只有微信 `com.tencent.mm` 是前台窗口时才执行手势；颜色分类不确定、出现超过 2048 的新方块颜色或棋盘验证失败时自动停下。
- **悬浮窗防遮挡（v0.1.1）**：当控制面板挡住棋盘时，截图前自动临时隐藏蓝色控制面板，避免截图识别成辅助窗颜色；暂停、重新框选或失败后也会恢复面板并丢弃旧截图。
- **隐私**：无需 Root、服务器、网络权限、录屏服务、ADB，也不上传截图；但无障碍权限本身非常敏感，只应授予自己审查、信任的应用。

## 构建 APK：方式 A（电脑上用 Android Studio）

1. 安装新版 Android Studio，打开本文件夹 `2048AIAndroid`。
2. 等待 Gradle 同步完成，首次需要从 Google Maven 下载编译依赖；电脑须能访问 Google Maven 或配置镜像。
3. 菜单 `Build > Build Bundle(s) / APK(s) > Build APK(s)`。
4. 在 `app/build/outputs/apk/debug/app-debug.apk` 找到生成的文件并传到安卓手机安装。

版本需求：JDK 17、Android SDK Platform 35、Gradle 8.7、Android Gradle Plugin 8.6.1。无需 Google ML Kit 依赖。
如果 Android Studio 没有 Gradle Wrapper，可在电脑安装 Gradle 8.7，再在项目目录执行 `gradle assembleDebug`。

## 构建 APK：方式 B（不用电脑，GitHub Actions 云端编译）

工程含 `.github/workflows/build-apk.yml`。如果你沿用此前仓库内「上传ZIP并由工作流解压」的方式，直接将新 ZIP **按相同文件名**替换仓库根目录旧 ZIP，然后点 `Commit changes`；仓库已有的工作流会自动重新编译：

也可以重新创建仓库，把解压后的完整工程源码上传：

1. 将**解压后的工程文件及目录结构**上传到自己的 GitHub 仓库（或者沿用上一段的 ZIP 解压流程）。
2. 仓库的 **Actions** 页面进入 **Build debug APK**，点击 **Run workflow**；也可以推送到 `main` 自动触发。
3. 成功后，在对应的运行详情页下载名称为 `2048-AI-Android-debug-apk` 的 artifact，解压得到 `app-debug.apk`。
4. 将 APK 安装到手机，首次使用必须手动开启无障碍权限。

GitHub Actions 需要网络拉取 Android SDK 与 Android Gradle 构建插件，也需要你有权在自己的仓库运行 Actions。

## 在手机上操作

1. 安装 APK；打开应用点击「开启无障碍服务」。
2. 安卓设置 → 无障碍 → 已下载/已安装的服务 → `2048 棋盘识别与滑动辅助器` → 开启。
3. **Android 13 特别注意**：若提示“受限设置”，可在你确认信任**自己编译的代码**后，进入「设置 → 应用 → 2048 AI 辅助器 → 右上角更多 → 允许受限设置」，返回无障碍界面再开启。不同品牌名称可能不同。这一权限允许程序看屏幕并操纵界面，应谨慎使用。
4. 打开微信的 2048 游戏；看到左上方的小悬浮窗。
5. 点「框选棋盘」，拖出整个游戏网格的正方形区域（不要把游戏标题、计分板框进去）。
6. 点「实时识别」，在悬浮窗逐格核对数字。如果有错，重新框选；识别不确定时会自动暂停。
7. 棋盘识别准确后点「单步」或「自动」。随时点「暂停自动」「停止识别」「隐藏」。
8. 如果悬浮窗挡住棋盘，可拖动悬浮窗标题，把它移到棋盘以外；安卓 11–13 的系统截图可能包含悬浮窗本身。

## 已知局限（重要）

- **已使用这款微信小程序的两张截图分别验证 16/16 格识别正确，但尚未在真实手机上进行无障碍与滑动实机测试。** 本版只识别这款皮肤截至 2048 的颜色，出现 4096 及以上新颜色时会暂停，以免误操作。
- 只支持标准的 4×4、每步出现一个 2 或 4 的玩法；其他尺寸、特殊道具、一次刷多个方块，需改 `Board`/`BoardRecognizer`。
- 无障碍服务截图要求 Android 11/API 30 或更新。若小游戏对截图设置了 `FLAG_SECURE`，则无法读取。
- 在部分 MIUI/HyperOS/厂商 ROM 上，无障碍截图、手势以及悬浮窗可能受额外限制。
- Expectimax 是启发式搜索，并不保证一定得到 2048 或更高分；算法评估和滑动顺序在本地完成，不连接本对话里的 AI 服务器。
- 校准位置以当前屏幕分辨率为准；屏幕旋转、分屏、横竖屏改变后应重新框选。
- 仅供你自行操作自己的小游戏；遵守游戏规则，避免自动化功能用于需要公平竞争的排行或比赛。

## 目录

```text
app/src/main/java/com/seanyu/ai2048/
  MainActivity.java      主应用、权限入口
  AssistService.java     屏幕截图、悬浮窗、滑动操作、步后校验
  CalibrationView.java   一次性框选棋盘
  BoardRecognizer.java   读取每格背景色
  TilePalette.java       截图实测配色分类表
  Board.java             游戏棋盘模型、方向移动与合并
  Solver.java            Expectimax + 启发式评估
app/src/main/res/xml/accessibility_service_config.xml
.github/workflows/build-apk.yml  在 GitHub 上自动构建 APK

dev-tests/SolverSelfTest.java 无 Android 依赖的算法自测
dev-tests/PaletteSelfTest.java 截图颜色表自测
```

## 自测决策算法与截图颜色分类（可选）

在仓库根目录执行：

```bash
mkdir -p /tmp/ai2048-classes
javac -d /tmp/ai2048-classes app/src/main/java/com/seanyu/ai2048/Board.java app/src/main/java/com/seanyu/ai2048/Solver.java app/src/main/java/com/seanyu/ai2048/TilePalette.java dev-tests/SolverSelfTest.java dev-tests/PaletteSelfTest.java
java -cp /tmp/ai2048-classes SolverSelfTest
java -cp /tmp/ai2048-classes PaletteSelfTest
```


### 关于直接安装的 APK

本次生成环境没有 Android SDK/Gradle，且不能联网安装这些组件，因此无法提供经过实际编译与签名的 APK。请不要把源码 ZIP 改后缀成 APK。若只有手机，请使用项目中的 GitHub Actions 工作流在线编译。
