package com.seanyu.ai2048;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/** Drag around the entire game board; screenshots use screen-space coordinates. */
public final class CalibrationView extends View {
    public interface Callback { void onSelected(Rect screenRect); }
    private final Paint pen = new Paint(3);
    private final Callback callback;
    private float startX, startY, currentX, currentY;
    private boolean dragging;

    public CalibrationView(Context context, Callback cb) {
        super(context);
        callback = cb;
        setBackgroundColor(0x55000000);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        pen.setColor(Color.WHITE);
        pen.setTextSize(dp(19));
        pen.setStyle(Paint.Style.FILL);
        canvas.drawText("框住 2048 的完整 4×4 棋盘", dp(18), dp(82), pen);
        pen.setTextSize(dp(14));
        canvas.drawText("从左上角拖到右下角（包含棋盘边框）", dp(18), dp(113), pen);
        if (dragging) {
            RectF square = selection();
            pen.setColor(0x3300CCFF);
            canvas.drawRect(square, pen);
            pen.setColor(0xFF20D7FF);
            pen.setStyle(Paint.Style.STROKE);
            pen.setStrokeWidth(dp(3));
            canvas.drawRect(square, pen);
            pen.setStyle(Paint.Style.FILL);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                startX = event.getX(); startY = event.getY();
                currentX = startX; currentY = startY;
                dragging = true; invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                currentX = event.getX(); currentY = event.getY();
                invalidate(); return true;
            case MotionEvent.ACTION_UP:
                currentX = event.getX(); currentY = event.getY();
                RectF rect = selection();
                dragging = false; invalidate();
                if (rect.width() < dp(140)) return true;
                int[] location = new int[2];
                getLocationOnScreen(location);
                Rect result = new Rect(
                        Math.round(rect.left) + location[0],
                        Math.round(rect.top) + location[1],
                        Math.round(rect.right) + location[0],
                        Math.round(rect.bottom) + location[1]);
                callback.onSelected(result);
                return true;
            default: return true;
        }
    }

    private RectF selection() {
        float left = Math.min(startX, currentX);
        float top = Math.min(startY, currentY);
        // The 2048 board should be square; deliberately enforce aspect ratio.
        float side = Math.min(Math.abs(currentX - startX), Math.abs(currentY - startY));
        return new RectF(left, top, left + side, top + side);
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
