package com.seanyu.ai2048;

/**
 * Colors measured from the user's exact WeChat mini-game screenshots.
 * Uses only the flat tile background, never text, so it needs no OCR model.
 * Pure Java to make it easy to test without an Android device.
 */
public final class TilePalette {
    private TilePalette() { }

    // 0 is an unoccupied cell. The other values are powers of two.
    public static final int[] VALUES = {
            0, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096
    };

    // Screenshot RGB (the user-supplied mini-game at 707x1536 pixels).
    private static final int[][] RGB = {
            {202, 190, 178}, // empty
            {238, 228, 218}, // 2
            {235, 220, 197}, // 4
            {245, 178, 125}, // 8
            {246, 150, 100}, // 16
            {247, 127,  93}, // 32
            {246,  91,  60}, // 64
            {237, 206, 115}, // 128
            {236, 202,  95}, // 256
            {238, 199,  80}, // 512
            {237, 197,  65}, // 1024
            {238, 193,  48}, // 2048
            {255,  61,  62}  // 4096, measured from the 691x1536 screenshot
    };

    /** RGB sample should come from the interior tile corners, away from digits. */
    public static int decode(int r, int g, int b) {
        int first = Integer.MAX_VALUE;
        int second = Integer.MAX_VALUE;
        int best = -1;
        for (int i = 0; i < RGB.length; i++) {
            int dr = r - RGB[i][0];
            int dg = g - RGB[i][1];
            int db = b - RGB[i][2];
            int d = dr * dr + dg * dg + db * db;
            if (d < first) {
                second = first;
                first = d;
                best = i;
            } else if (d < second) {
                second = d;
            }
        }
        // If the color is unknown, or equally likely to be two adjacent golds,
        // stop rather than letting a false number trigger an automated move.
        if (first > 25 * 25 || Math.sqrt(second) - Math.sqrt(first) < 6.0) return -1;
        return VALUES[best];
    }
}
