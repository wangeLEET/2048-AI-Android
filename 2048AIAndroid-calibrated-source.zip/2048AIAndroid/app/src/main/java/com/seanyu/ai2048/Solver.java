package com.seanyu.ai2048;

import java.util.ArrayList;
import java.util.List;

/** Expectimax with chance nodes and a bounded stochastic-location approximation. */
public final class Solver {
    private static final int MAX_CHANCE_LOCATIONS = 5;
    private static final double NEGATIVE = -1e20;

    public static final class Choice {
        public final int direction;
        public final double score;
        Choice(int direction, double score) {
            this.direction = direction;
            this.score = score;
        }
    }

    public Choice choose(Board board) {
        int bestDirection = -1;
        double best = NEGATIVE;
        for (int dir = 0; dir < 4; dir++) {
            Board.Move move = board.move(dir);
            if (!move.changed) continue;
            // Two additional planning turns; bounded search for on-device performance.
            double value = chance(move.board, 2) + move.gained * 0.08;
            if (value > best) {
                best = value;
                bestDirection = dir;
            }
        }
        return new Choice(bestDirection, best);
    }

    private double player(Board b, int depth) {
        if (depth <= 0) return heuristic(b);
        double best = NEGATIVE;
        boolean hasMove = false;
        for (int direction = 0; direction < 4; direction++) {
            Board.Move move = b.move(direction);
            if (!move.changed) continue;
            hasMove = true;
            double value = chance(move.board, depth - 1) + move.gained * 0.08;
            best = Math.max(best, value);
        }
        return hasMove ? best : heuristic(b) - 100000;
    }

    private double chance(Board b, int depth) {
        if (depth <= 0) return heuristic(b);
        List<Integer> empty = new ArrayList<>();
        for (int i = 0; i < 16; i++) if (b.cells[i] == 0) empty.add(i);
        if (empty.isEmpty()) return player(b, depth);
        // Evenly cover board positions. Approximate all-spawn expectation for speed.
        int tested = Math.min(empty.size(), MAX_CHANCE_LOCATIONS);
        double total = 0;
        for (int sample = 0; sample < tested; sample++) {
            int at = empty.get((int) ((long) sample * empty.size() / tested));
            int[] v = b.cells.clone();
            v[at] = 2;
            total += 0.9 * player(new Board(v), depth);
            v[at] = 4;
            total += 0.1 * player(new Board(v), depth);
        }
        return total / tested;
    }

    private double heuristic(Board b) {
        int[] a = b.cells;
        double smooth = 0, monotonic = 0, merges = 0;
        int empty = 0, largest = 0;
        int[] ranks = new int[16];
        for (int i = 0; i < 16; i++) {
            int value = a[i];
            ranks[i] = value == 0 ? 0 : 31 - Integer.numberOfLeadingZeros(value);
            if (value == 0) empty++;
            largest = Math.max(largest, value);
        }
        for (int row = 0; row < 4; row++) {
            double ascend = 0, descend = 0;
            for (int col = 0; col < 3; col++) {
                int i = row * 4 + col;
                ascend += Math.max(0, ranks[i + 1] - ranks[i]);
                descend += Math.max(0, ranks[i] - ranks[i + 1]);
                if (a[i] != 0 && a[i + 1] != 0) {
                    smooth += Math.abs(ranks[i] - ranks[i + 1]);
                    if (a[i] == a[i + 1]) merges++;
                }
            }
            monotonic += Math.min(ascend, descend);
        }
        for (int col = 0; col < 4; col++) {
            double ascend = 0, descend = 0;
            for (int row = 0; row < 3; row++) {
                int i = row * 4 + col;
                ascend += Math.max(0, ranks[i + 4] - ranks[i]);
                descend += Math.max(0, ranks[i] - ranks[i + 4]);
                if (a[i] != 0 && a[i + 4] != 0) {
                    smooth += Math.abs(ranks[i] - ranks[i + 4]);
                    if (a[i] == a[i + 4]) merges++;
                }
            }
            monotonic += Math.min(ascend, descend);
        }
        boolean corner = largest > 0 && (a[0] == largest || a[3] == largest
                || a[12] == largest || a[15] == largest);
        int maxRank = largest == 0 ? 0 : 31 - Integer.numberOfLeadingZeros(largest);
        return empty * 270 - monotonic * 53 - smooth * 9 + merges * 35
                + (corner ? maxRank * 115 : 0) + maxRank * 12;
    }
}
