package com.seanyu.ai2048;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private TextView status;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xFFF6F7FA);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(25), dp(44), dp(25), dp(24));
        scroll.addView(root);

        TextView heading = text("2048 AI 辅助器", 26, 0xFF16212C, true);
        root.addView(heading);
        root.addView(text("微信小程序 · 颜色识别 · Expectimax", 14, 0xFF66717C, false));
        root.addView(space(22));
        root.addView(text("1. 打开无障碍设置，启用「2048 棋盘识别与滑动辅助器」。\n\n"
                + "2. 打开微信的2048小程序。悬浮窗会显示在屏幕上。\n\n"
                + "3. 点击「框选棋盘」，用手指划出完整的4×4方格范围。\n\n"
                + "4. 点击「实时识别」，确认显示的16格数字正确。\n\n"
                + "5. 点击「自动」会进入极速模式，屏幕顶部的「■ 停止」按钮随时暂停。", 16, 0xFF303943, false));
        root.addView(space(24));

        Button settings = button("① 开启无障碍服务");
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(settings);

        Button panel = button("② 显示游戏悬浮窗");
        panel.setOnClickListener(v -> {
            if (AssistService.instance != null) {
                AssistService.instance.showPanel();
                status.setText("悬浮窗已显示，返回微信即可使用。");
            } else {
                status.setText("无障碍服务尚未开启；先完成上一步。");
            }
        });
        root.addView(panel);

        Button wechat = button("③ 打开微信");
        wechat.setOnClickListener(v -> {
            Intent launch = getPackageManager().getLaunchIntentForPackage("com.tencent.mm");
            if (launch != null) startActivity(launch);
            else status.setText("未找到微信，请手动打开微信2048小程序。");
        });
        root.addView(wechat);
        root.addView(space(18));
        status = text("极速自动模式不再每一步隐藏悬浮面板；按「■ 停止」立即暂停下一步。", 14, 0xFF52616C, false);
        root.addView(status);
        root.addView(space(16));
        root.addView(text("隐私：仅在手机本地识别，不需要网络权限，不上传截图。"
                + "\n\n限制：已按你提供的两张微信2048截图适配颜色；如果游戏换皮肤、出现4096或更高数字，识别会暂停，"
                + "识别不确定时程序会暂停，不保证每款小游戏都能直接兼容。", 13, 0xFF65737E, false));
        setContentView(scroll);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(15);
        b.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54));
        p.bottomMargin = dp(10);
        b.setLayoutParams(p);
        return b;
    }

    private TextView text(String label, int sizeSp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(label);
        v.setTextSize(sizeSp);
        v.setTextColor(color);
        v.setLineSpacing(dp(3), 1);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private View space(int dp) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(dp)));
        return v;
    }

    private int dp(float n) { return Math.round(n * getResources().getDisplayMetrics().density); }
}
