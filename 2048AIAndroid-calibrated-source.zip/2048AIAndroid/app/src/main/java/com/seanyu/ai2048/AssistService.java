package com.seanyu.ai2048;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ColorSpace;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Typeface;

/** Android 11+ accessibility screenshot + gesture assistant; NO root, network or MediaProjection. */
public final class AssistService extends AccessibilityService {
    public static AssistService instance;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Solver solver = new Solver();
    private final BoardRecognizer vision = new BoardRecognizer();
    private final Runnable nextCapture = this::takeBoardScreenshot;

    private WindowManager wm;
    private LinearLayout panel;
    private WindowManager.LayoutParams panelParams;
    private Button miniStopButton;
    private View miniHud;
    private boolean fastHudMode;
    private int screenshotThrottleFailures;
    private long adaptiveScreenshotIntervalMs = MIN_SCREENSHOT_INTERVAL_MS;
    private long lastVerifiedMoveAt;
    private long averageCycleMs;
    private CalibrationView calibration;
    private TextView statusView, boardView, bestView;
    private Button watchButton, autoButton;
    private Rect boardRect;
    private Board previousBoard;
    private Board awaitingSpawnFrom;
    private int verificationRetries;
    private boolean watch, auto, oneShot, busy, performingGesture;
    private long lastScreenshotTime;
    private int moveCount;
    // Accessibility screenshots capture TYPE_ACCESSIBILITY_OVERLAY windows too.
    // Hide our own panel, wait for the compositor to redraw, then take the shot.
    private static final long OVERLAY_SETTLE_MS = 110;
    // AOSP limits AccessibilityService screenshots to about 333 ms.
    // Keep a small safety margin; no blind 650 ms sleep on every move.
    private static final long MIN_SCREENSHOT_INTERVAL_MS = 365;
    private static final long FAST_GESTURE_MS = 105;
    private static final long SLOW_GESTURE_MS = 185;
    private boolean panelHiddenForScreenshot;
    private int captureGeneration;
    private Runnable delayedCapture;
    // The foreground-window check incorrectly rejects WeChat mini-programs after
    // a button on our accessibility overlay is pressed. A fresh, color-validated
    // board screenshot is our gesture gate instead.
    private static final long GESTURE_OVERLAY_SETTLE_MS = 100;
    private boolean panelHiddenForGesture;
    private int gestureGeneration;
    private Runnable delayedGesture;
    private Runnable gestureWatchdog;

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        SharedPreferences prefs = getSharedPreferences("board", MODE_PRIVATE);
        if (prefs.contains("left")) {
            boardRect = new Rect(prefs.getInt("left", 0), prefs.getInt("top", 0),
                    prefs.getInt("right", 0), prefs.getInt("bottom", 0));
        }
        showPanel();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* No screen text logging. */ }
    @Override public void onInterrupt() { stopAll("无障碍服务中断"); }

    @Override public void onDestroy() {
        stopAll("服务已关闭");
        ui.removeCallbacksAndMessages(null);
        removeCalibration();
        hidePanel();
        removeMiniHud();
        vision.close();
        instance = null;
        super.onDestroy();
    }

    public void showPanel() {
        if (wm == null) return;
        if (panel != null) {
            if (!auto && panel.getVisibility() != View.VISIBLE) panel.setVisibility(View.VISIBLE);
            return;
        }
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(8), dp(10), dp(10));
        panel.setBackground(makeBackground());

        TextView title = text("2048 AI  ·  拖动这里移动窗口", 13, Color.WHITE, true);
        title.setPadding(dp(4), dp(2), dp(4), dp(8));
        panel.addView(title);
        title.setOnTouchListener(new View.OnTouchListener() {
            private float startRawX, startRawY;
            private int startWindowX, startWindowY;
            @Override public boolean onTouch(View v, MotionEvent ev) {
                if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    startRawX = ev.getRawX(); startRawY = ev.getRawY();
                    startWindowX = panelParams.x; startWindowY = panelParams.y;
                    return true;
                }
                if (ev.getActionMasked() == MotionEvent.ACTION_MOVE) {
                    panelParams.x = Math.max(0, startWindowX + Math.round(ev.getRawX() - startRawX));
                    panelParams.y = Math.max(0, startWindowY + Math.round(ev.getRawY() - startRawY));
                    try { wm.updateViewLayout(panel, panelParams); }
                    catch (IllegalArgumentException ignored) { }
                    return true;
                }
                return true;
            }
        });

        statusView = text("先在微信打开2048，再框选棋盘", 12, 0xFFE8F1F7, false);
        statusView.setMaxLines(3);
        panel.addView(statusView);
        boardView = text("    ·    ·    ·    ·\n    ·    ·    ·    ·\n    ·    ·    ·    ·\n    ·    ·    ·    ·", 12, Color.WHITE, false);
        boardView.setTypeface(Typeface.MONOSPACE);
        boardView.setPadding(dp(3), dp(5), dp(3), dp(3));
        panel.addView(boardView);
        bestView = text("推荐：等待识别", 16, 0xFF83E4FC, true);
        panel.addView(bestView);

        LinearLayout row1 = new LinearLayout(this);
        Button select = smallButton("框选棋盘");
        select.setOnClickListener(v -> showCalibration());
        watchButton = smallButton("实时识别");
        watchButton.setOnClickListener(v -> toggleWatch());
        row1.addView(select, weightParams());
        row1.addView(watchButton, weightParams());
        panel.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        Button step = smallButton("单步");
        step.setOnClickListener(v -> {
            if (boardRect == null) { status("请先框选棋盘"); return; }
            if (auto || performingGesture || awaitingSpawnFrom != null) {
                status("请先暂停自动模式，或等待这一步执行完毕"); return;
            }
            oneShot = true;
            watch = true;
            updateButtons();
            schedule(50);
        });
        autoButton = smallButton("自动");
        autoButton.setOnClickListener(v -> {
            if (auto) {
                stopAll("自动操作已暂停");
            } else {
                if (boardRect == null) { status("请先框选棋盘"); return; }
                auto = true; watch = true; oneShot = false;
                lastVerifiedMoveAt = 0;
                averageCycleMs = 0;
                // During automatic play, keep only a tiny STOP control
                // strictly outside the calibrated board. No compositor
                // show/hide roundtrips between screenshots and swipes.
                fastHudMode = showMiniHudOutsideBoard();
                if (fastHudMode && panel != null) panel.setVisibility(View.GONE);
                status(fastHudMode
                        ? "极速模式已启动（顶部悬浮按钮可停止）"
                        : "普通自动模式：无法在棋盘外安放停止按钮");
                schedule(20);
            }
            updateButtons();
        });
        Button hide = smallButton("隐藏");
        hide.setOnClickListener(v -> {
            stopAll("悬浮窗已隐藏");
            hidePanel();
        });
        row2.addView(step, weightParams());
        row2.addView(autoButton, weightParams());
        row2.addView(hide, weightParams());
        panel.addView(row2);

        panelParams = new WindowManager.LayoutParams(
                dp(294), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.LEFT;
        panelParams.x = dp(8);
        panelParams.y = dp(60);
        try { wm.addView(panel, panelParams); }
        catch (RuntimeException e) { panel = null; }
        updateButtons();
    }

    private android.graphics.drawable.GradientDrawable makeBackground() {
        android.graphics.drawable.GradientDrawable b = new android.graphics.drawable.GradientDrawable();
        b.setColor(0xEC142331);
        b.setCornerRadius(dp(14));
        b.setStroke(dp(1), 0xFF617D92);
        return b;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(41), 1f);
        p.setMargins(dp(2), dp(4), dp(2), dp(1));
        return p;
    }

    private Button smallButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(11);
        button.setAllCaps(false);
        button.setPadding(0, 0, 0, 0);
        return button;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void updateButtons() {
        if (watchButton != null) watchButton.setText(watch ? "停止识别" : "实时识别");
        if (autoButton != null) autoButton.setText(auto ? "暂停自动" : "自动");
        if (miniStopButton != null) miniStopButton.setText("■ 停止  " + moveCount + "步");
    }

    private void status(String message) {
        if (statusView != null) statusView.setText(message);
    }

    /**
     * Keep just one compact, tappable emergency-stop HUD during auto play.
     * The selected 4x4 board remains fully unobscured in screenshots/gestures.
     * If there is no safe docking space, fall back to the regular overlay path.
     */
    private boolean showMiniHudOutsideBoard() {
        removeMiniHud();
        if (wm == null || boardRect == null) return false;
        Rect screen = wm.getCurrentWindowMetrics().getBounds();
        int width = dp(170);
        int height = dp(48);
        int inset = dp(12);
        int y;
        if (inset + height + dp(8) <= boardRect.top) {
            y = inset;
        } else if (boardRect.bottom + dp(8) + height + inset <= screen.height()) {
            y = boardRect.bottom + dp(8);
        } else {
            return false;
        }
        int x = Math.max(inset, Math.min((screen.width() - width) / 2,
                screen.width() - width - inset));
        if (Rect.intersects(new Rect(x, y, x + width, y + height), boardRect)) {
            return false;
        }
        Button stop = new Button(this);
        stop.setAllCaps(false);
        stop.setTextSize(13);
        stop.setTextColor(Color.WHITE);
        stop.setText("■ 停止  " + moveCount + "步");
        stop.setPadding(dp(8), 0, dp(8), 0);
        android.graphics.drawable.GradientDrawable shape =
                new android.graphics.drawable.GradientDrawable();
        shape.setColor(0xEE173145);
        shape.setCornerRadius(dp(16));
        shape.setStroke(dp(1), 0xFF5EB6D5);
        stop.setBackground(shape);
        stop.setOnClickListener(v -> stopAll("自动操作已暂停 · " + moveCount + "步"));
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(width, height,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        lp.x = x;
        lp.y = y;
        try {
            wm.addView(stop, lp);
            miniHud = stop;
            miniStopButton = stop;
            return true;
        } catch (RuntimeException ignored) {
            miniHud = null;
            miniStopButton = null;
            return false;
        }
    }

    private void removeMiniHud() {
        if (miniHud != null && wm != null) {
            try { wm.removeView(miniHud); }
            catch (RuntimeException ignored) { }
        }
        miniHud = null;
        miniStopButton = null;
        fastHudMode = false;
    }

    private void toggleWatch() {
        watch = !watch;
        if (!watch) {
            stopAll("实时识别已暂停");
        } else {
            status("正在读取棋盘…");
            schedule(50);
        }
        updateButtons();
    }

    private void showCalibration() {
        if (wm == null || calibration != null) return;
        stopAll("正在校准棋盘");
        if (panel != null) panel.setVisibility(View.GONE);
        calibration = new CalibrationView(this, rect -> {
            boardRect = rect;
            getSharedPreferences("board", MODE_PRIVATE).edit()
                    .putInt("left", rect.left).putInt("top", rect.top)
                    .putInt("right", rect.right).putInt("bottom", rect.bottom).apply();
            vision.resetColors();
            previousBoard = null;
            removeCalibration();
            if (panel != null) panel.setVisibility(View.VISIBLE);
            status("已框选棋盘。点击「实时识别」，先核对数字");
        });
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        try { wm.addView(calibration, params); }
        catch (RuntimeException e) {
            calibration = null;
            if (panel != null) panel.setVisibility(View.VISIBLE);
            status("无法显示框选窗口");
        }
    }

    private void removeCalibration() {
        if (calibration == null) return;
        try { wm.removeView(calibration); }
        catch (RuntimeException ignored) { }
        calibration = null;
    }

    private void hidePanel() {
        if (panel != null && wm != null) {
            restorePanelAfterScreenshot();
            try { wm.removeView(panel); }
            catch (RuntimeException ignored) { }
        }
        panel = null;
        statusView = null;
        boardView = null;
        bestView = null;
        watchButton = null;
        autoButton = null;
    }

    private void stopAll(String reason) {
        watch = false;
        auto = false;
        oneShot = false;
        removeMiniHud();
        if (panel != null && calibration == null) panel.setVisibility(View.VISIBLE);
        awaitingSpawnFrom = null;
        screenshotThrottleFailures = 0;
        // Discard any delayed/in-flight screenshot callbacks, including ones from
        // the previous board calibration. Never leave the overlay invisible.
        captureGeneration++;
        if (delayedCapture != null) {
            ui.removeCallbacks(delayedCapture);
            delayedCapture = null;
        }
        ui.removeCallbacks(nextCapture);
        // Cancel pending swipe after pause/recalibration. An already dispatched
        // system gesture cannot be interrupted, but its stale callback is ignored.
        gestureGeneration++;
        if (delayedGesture != null) {
            ui.removeCallbacks(delayedGesture);
            delayedGesture = null;
        }
        if (gestureWatchdog != null) {
            ui.removeCallbacks(gestureWatchdog);
            gestureWatchdog = null;
        }
        performingGesture = false;
        restorePanelAfterGesture();
        restorePanelAfterScreenshot();
        busy = false;
        status(reason + (averageCycleMs > 0 ? " · 最近约" + averageCycleMs + "ms/步" : ""));
        updateButtons();
    }

    private void schedule(long delayMs) {
        ui.removeCallbacks(nextCapture);
        if ((watch || auto || oneShot || awaitingSpawnFrom != null)
                && boardRect != null && calibration == null) {
            ui.postDelayed(nextCapture, Math.max(delayMs, 0));
        }
    }

    /** Hide blue controls only when they overlap the selected board. */
    private void hidePanelForScreenshot() {
        if (panel == null || panel.getVisibility() != View.VISIBLE || boardRect == null) return;
        int[] xy = new int[2];
        panel.getLocationOnScreen(xy);
        Rect panelBounds = new Rect(xy[0], xy[1],
                xy[0] + panel.getWidth(), xy[1] + panel.getHeight());
        if (Rect.intersects(panelBounds, boardRect)) {
            panel.setVisibility(View.INVISIBLE);
            panelHiddenForScreenshot = true;
        }
    }

    private void restorePanelAfterScreenshot() {
        if (!panelHiddenForScreenshot) return;
        panelHiddenForScreenshot = false;
        // An active gesture may still need the overlay out of the way.
        if (panel != null && calibration == null && !panelHiddenForGesture) {
            panel.setVisibility(View.VISIBLE);
        }
    }

    private void hidePanelForGesture() {
        if (panel != null && panel.getVisibility() == View.VISIBLE) {
            panel.setVisibility(View.INVISIBLE);
            panelHiddenForGesture = true;
        }
    }

    private void restorePanelAfterGesture() {
        if (!panelHiddenForGesture) return;
        panelHiddenForGesture = false;
        if (panel != null && calibration == null && !panelHiddenForScreenshot) {
            panel.setVisibility(View.VISIBLE);
        }
    }

    /** Return false for stale callbacks after Pause, Hide, or Recalibrate. */
    private boolean finishScreenshot(int request) {
        if (request != captureGeneration) return false;
        restorePanelAfterScreenshot();
        busy = false;
        return true;
    }

    private void takeBoardScreenshot() {
        if (boardRect == null || busy || performingGesture || calibration != null) return;
        if (!(watch || auto || oneShot || awaitingSpawnFrom != null)) return;
        long elapsed = android.os.SystemClock.uptimeMillis() - lastScreenshotTime;
        if (elapsed < adaptiveScreenshotIntervalMs) {
            schedule(adaptiveScreenshotIntervalMs - elapsed);
            return;
        }

        // The tiny STOP HUD is always placed outside the board. Verify its
        // actual window position after layout; fall back to safe, slower mode
        // if an unusual display inset moved it over the calibrated area.
        if (fastHudMode && miniHud != null && miniHud.getWidth() > 0) {
            int[] pos = new int[2];
            miniHud.getLocationOnScreen(pos);
            if (Rect.intersects(new Rect(pos[0], pos[1],
                    pos[0] + miniHud.getWidth(), pos[1] + miniHud.getHeight()), boardRect)) {
                removeMiniHud();
                if (panel != null) panel.setVisibility(View.VISIBLE);
                status("小按钮与棋盘重叠，已切换安全模式；请重新框选");
            }
        }

        busy = true;
        final int request = ++captureGeneration;
        hidePanelForScreenshot();

        // If we hid a panel, wait for SurfaceFlinger to compose a clean frame.
        // Otherwise capture promptly without making the panel blink.
        delayedCapture = () -> {
            delayedCapture = null;
            if (request != captureGeneration) return;
            if (boardRect == null || calibration != null || performingGesture
                    || !(watch || auto || oneShot || awaitingSpawnFrom != null)) {
                finishScreenshot(request);
                return;
            }
            captureWithoutOverlay(request);
        };
        ui.postDelayed(delayedCapture, panelHiddenForScreenshot ? OVERLAY_SETTLE_MS : 0);
    }

    private void captureWithoutOverlay(final int request) {
        lastScreenshotTime = android.os.SystemClock.uptimeMillis();
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                @Override public void onSuccess(ScreenshotResult screenshot) {
                    screenshotThrottleFailures = 0;
                    HardwareBuffer hardware = screenshot.getHardwareBuffer();
                    if (!finishScreenshot(request)) {
                        if (hardware != null) hardware.close();
                        return;
                    }
                    Bitmap source = null;
                    try {
                        if (hardware == null) throw new IllegalStateException("截图缓冲区为空");
                        ColorSpace space = screenshot.getColorSpace();
                        Bitmap wrapped = Bitmap.wrapHardwareBuffer(hardware,
                                space != null ? space : ColorSpace.get(ColorSpace.Named.SRGB));
                        if (wrapped == null) throw new IllegalStateException("无法解码屏幕画面");
                        try {
                            source = wrapped.copy(Bitmap.Config.ARGB_8888, false);
                        } finally {
                            wrapped.recycle();
                        }
                        if (source == null) throw new IllegalStateException("屏幕复制失败");
                    } catch (Exception e) {
                        status("截图解析失败：" + e.getMessage());
                        if (auto) stopAll("自动操作已暂停：截图失败");
                        else schedule(1400);
                        return;
                    } finally {
                        if (hardware != null) hardware.close();
                    }
                    try {
                        vision.read(source, boardRect, (board, error) -> onRecognized(board, error));
                    } catch (RuntimeException e) {
                        stopAll("识别程序异常：" + e.getClass().getSimpleName());
                    } finally {
                        source.recycle();
                    }
                }

                @Override public void onFailure(int errorCode) {
                    if (!finishScreenshot(request)) return;
                    if (errorCode == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT
                            && ++screenshotThrottleFailures <= 5) {
                        // Some ROMs enforce a larger screenshot interval.
                        // Back off safely without losing the current move.
                        adaptiveScreenshotIntervalMs =
                                Math.min(1050, adaptiveScreenshotIntervalMs + 120);
                        status("系统限制截图频率，间隔调整至 "
                                + adaptiveScreenshotIntervalMs + "ms");
                        schedule(adaptiveScreenshotIntervalMs);
                    } else if (auto) {
                        stopAll("自动操作停止：截图失败（错误" + errorCode + "）");
                    } else {
                        status("截图失败：" + errorCode + "。检查无障碍权限和游戏窗口");
                        schedule(1200);
                    }
                }
            });
        } catch (RuntimeException e) {
            if (finishScreenshot(request)) {
                stopAll("截图接口调用失败：" + e.getClass().getSimpleName());
            }
        }
    }

    private void onRecognized(Board board, String error) {
        if (calibration != null || !(watch || auto || oneShot || awaitingSpawnFrom != null)) return;
        if (error != null) {
            if (awaitingSpawnFrom != null && ++verificationRetries <= 5) {
                status("等待动画/重新识别（" + verificationRetries + "/5）：" + error);
                schedule(90);
                return;
            }
            if (auto || oneShot || awaitingSpawnFrom != null) {
                stopAll("自动已停止：" + error);
            } else {
                status(error);
                schedule(1100);
            }
            return;
        }
        if (board == null) {
            stopAll("识别结果为空"); return;
        }
        // Verify the previous action BEFORE running an expensive solver search.
        // Frames captured during animation must never generate another swipe.
        if (awaitingSpawnFrom != null) {
            if (!awaitingSpawnFrom.isSingleSpawnFrom(board)) {
                verificationRetries++;
                if (verificationRetries > 5) {
                    stopAll("已停止：滑动后棋盘没有出现预期变化；请检查游戏是否响应手势");
                    return;
                }
                status("等待游戏动画与新方块（" + verificationRetries + "/5）");
                schedule(85);
                return;
            }
            long now = SystemClock.uptimeMillis();
            if (lastVerifiedMoveAt > 0) {
                long sample = now - lastVerifiedMoveAt;
                averageCycleMs = averageCycleMs == 0 ? sample : (averageCycleMs * 3 + sample) / 4;
            }
            lastVerifiedMoveAt = now;
            awaitingSpawnFrom = null;
            verificationRetries = 0;
        }
        previousBoard = board;
        if (!fastHudMode && boardView != null) boardView.setText(board.toDisplay());
        Solver.Choice choice = solver.choose(board);
        if (!fastHudMode && bestView != null) {
            bestView.setText(choice.direction < 0 ? "推荐：无合法移动" :
                    "推荐：" + Board.ARROWS[choice.direction] + "    最大格 " + board.largest());
        }
        if (fastHudMode) {
            if (miniStopButton != null) miniStopButton.setText("■ 停止  " + moveCount + "步");
        } else {
            status("已识别 · " + moveCount + " 次辅助操作 · 空格 " + board.emptyCount()
                    + (averageCycleMs > 0 ? " · 平均" + averageCycleMs + "ms/步" : ""));
        }
        if (choice.direction < 0) {
            stopAll("无合法移动：游戏可能已经结束");
            return;
        }
        if (auto || oneShot) {
            oneShot = false;
            executeMove(board, choice.direction);
        } else {
            schedule(950);
        }
    }

    private void executeMove(Board board, int direction) {
        // We arrive here ONLY from a successful, fresh 16-cell screenshot of
        // the selected 2048 board. getRootInActiveWindow() is not reliable here:
        // touching our accessibility overlay can make that method return our
        // own window (or null), even while the visible game is in WeChat.
        if (boardRect == null || performingGesture || calibration != null) {
            stopAll("无法发送滑动：请重新框选或等待识别完成");
            return;
        }
        Board.Move predicted = board.move(direction);
        if (!predicted.changed) {
            stopAll("推荐移动无效，已停止");
            return;
        }

        int cx = boardRect.centerX();
        int cy = boardRect.centerY();
        int delta = Math.round(Math.min(boardRect.width(), boardRect.height()) * 0.31f);
        int dx = direction == Board.RIGHT ? delta : direction == Board.LEFT ? -delta : 0;
        int dy = direction == Board.DOWN ? delta : direction == Board.UP ? -delta : 0;
        Path swipe = new Path();
        swipe.moveTo(cx, cy);
        swipe.lineTo(cx + dx, cy + dy);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(
                swipe, 0, fastHudMode ? FAST_GESTURE_MS : SLOW_GESTURE_MS));

        performingGesture = true;
        final int request = ++gestureGeneration;
        if (!fastHudMode) status("正在滑动：" + Board.ARROWS[direction]);
        // When the overlay overlaps the game, dispatching the gesture while
        // it is visible can direct the touch at our own panel instead.
        hidePanelForGesture();
        delayedGesture = () -> {
            delayedGesture = null;
            if (request != gestureGeneration || !performingGesture || boardRect == null) return;
            boolean accepted;
            try {
                accepted = dispatchGesture(builder.build(), new GestureResultCallback() {
                    @Override public void onCompleted(GestureDescription gestureDescription) {
                        if (request != gestureGeneration) return;
                        clearGestureWatchdog();
                        performingGesture = false;
                        restorePanelAfterGesture();
                        awaitingSpawnFrom = predicted.board;
                        verificationRetries = 0;
                        moveCount++;
                        if (!fastHudMode) status("已滑动 " + moveCount + " 次，正在核对棋盘…");
                        else updateButtons();
                        // Wait for the next allowable screenshot, not an extra 680 ms.
                        schedule(fastHudMode ? 35 : 320);
                    }
                    @Override public void onCancelled(GestureDescription gestureDescription) {
                        if (request != gestureGeneration) return;
                        clearGestureWatchdog();
                        performingGesture = false;
                        restorePanelAfterGesture();
                        stopAll("滑动被系统取消：检查无障碍手势权限");
                    }
                }, ui);
            } catch (RuntimeException ex) {
                performingGesture = false;
                restorePanelAfterGesture();
                stopAll("无法发送滑动：" + ex.getClass().getSimpleName());
                return;
            }
            if (!accepted) {
                performingGesture = false;
                restorePanelAfterGesture();
                stopAll("系统拒绝模拟滑动，请检查无障碍服务是否开启");
                return;
            }
            gestureWatchdog = () -> {
                gestureWatchdog = null;
                if (request == gestureGeneration && performingGesture) {
                    stopAll("滑动没有完成回调，请重新开启无障碍服务后重试");
                }
            };
            ui.postDelayed(gestureWatchdog, 2600);
        };
        ui.postDelayed(delayedGesture, fastHudMode ? 0 : GESTURE_OVERLAY_SETTLE_MS);
    }

    private void clearGestureWatchdog() {
        if (gestureWatchdog != null) {
            ui.removeCallbacks(gestureWatchdog);
            gestureWatchdog = null;
        }
    }

    private int dp(float n) { return Math.round(n * getResources().getDisplayMetrics().density); }
}
