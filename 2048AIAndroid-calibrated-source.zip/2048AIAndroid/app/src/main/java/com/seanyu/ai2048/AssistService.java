package com.seanyu.ai2048;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ColorSpace;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Typeface;

/** Android 11+ accessibility screenshot + gesture assistant; NO root, network or MediaProjection. */
public final class AssistService extends AccessibilityService {
    public static AssistService instance;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Solver solver = new Solver();
    private final BoardRecognizer vision = new BoardRecognizer();
    private final Runnable nextCapture = this::takeBoardScreenshot;

    private WindowManager wm;
    private LinearLayout panel;
    private WindowManager.LayoutParams panelParams;
    private CalibrationView calibration;
    private TextView statusView, boardView, bestView;
    private Button watchButton, autoButton;
    private Rect boardRect;
    private Board previousBoard;
    private Board awaitingSpawnFrom;
    private int verificationRetries;
    private boolean watch, auto, oneShot, busy, performingGesture;
    private long lastScreenshotTime;
    private int moveCount;

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        SharedPreferences prefs = getSharedPreferences("board", MODE_PRIVATE);
        if (prefs.contains("left")) {
            boardRect = new Rect(prefs.getInt("left", 0), prefs.getInt("top", 0),
                    prefs.getInt("right", 0), prefs.getInt("bottom", 0));
        }
        showPanel();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* No screen text logging. */ }
    @Override public void onInterrupt() { stopAll("无障碍服务中断"); }

    @Override public void onDestroy() {
        stopAll("服务已关闭");
        ui.removeCallbacksAndMessages(null);
        removeCalibration();
        hidePanel();
        vision.close();
        instance = null;
        super.onDestroy();
    }

    public void showPanel() {
        if (wm == null) return;
        if (panel != null) return;
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(8), dp(10), dp(10));
        panel.setBackground(makeBackground());

        TextView title = text("2048 AI  ·  拖动这里移动窗口", 13, Color.WHITE, true);
        title.setPadding(dp(4), dp(2), dp(4), dp(8));
        panel.addView(title);
        title.setOnTouchListener(new View.OnTouchListener() {
            private float startRawX, startRawY;
            private int startWindowX, startWindowY;
            @Override public boolean onTouch(View v, MotionEvent ev) {
                if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    startRawX = ev.getRawX(); startRawY = ev.getRawY();
                    startWindowX = panelParams.x; startWindowY = panelParams.y;
                    return true;
                }
                if (ev.getActionMasked() == MotionEvent.ACTION_MOVE) {
                    panelParams.x = Math.max(0, startWindowX + Math.round(ev.getRawX() - startRawX));
                    panelParams.y = Math.max(0, startWindowY + Math.round(ev.getRawY() - startRawY));
                    try { wm.updateViewLayout(panel, panelParams); }
                    catch (IllegalArgumentException ignored) { }
                    return true;
                }
                return true;
            }
        });

        statusView = text("先在微信打开2048，再框选棋盘", 12, 0xFFE8F1F7, false);
        statusView.setMaxLines(3);
        panel.addView(statusView);
        boardView = text("    ·    ·    ·    ·\n    ·    ·    ·    ·\n    ·    ·    ·    ·\n    ·    ·    ·    ·", 12, Color.WHITE, false);
        boardView.setTypeface(Typeface.MONOSPACE);
        boardView.setPadding(dp(3), dp(5), dp(3), dp(3));
        panel.addView(boardView);
        bestView = text("推荐：等待识别", 16, 0xFF83E4FC, true);
        panel.addView(bestView);

        LinearLayout row1 = new LinearLayout(this);
        Button select = smallButton("框选棋盘");
        select.setOnClickListener(v -> showCalibration());
        watchButton = smallButton("实时识别");
        watchButton.setOnClickListener(v -> toggleWatch());
        row1.addView(select, weightParams());
        row1.addView(watchButton, weightParams());
        panel.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        Button step = smallButton("单步");
        step.setOnClickListener(v -> {
            if (boardRect == null) { status("请先框选棋盘"); return; }
            if (auto || performingGesture || awaitingSpawnFrom != null) {
                status("请先暂停自动模式，或等待这一步执行完毕"); return;
            }
            oneShot = true;
            watch = true;
            updateButtons();
            schedule(50);
        });
        autoButton = smallButton("自动");
        autoButton.setOnClickListener(v -> {
            if (auto) {
                auto = false;
                status("自动操作已暂停");
            } else {
                if (boardRect == null) { status("请先框选棋盘"); return; }
                auto = true; watch = true; oneShot = false;
                status("自动模式已启动；识别异常时会自动停止");
                schedule(50);
            }
            updateButtons();
        });
        Button hide = smallButton("隐藏");
        hide.setOnClickListener(v -> {
            stopAll("悬浮窗已隐藏");
            hidePanel();
        });
        row2.addView(step, weightParams());
        row2.addView(autoButton, weightParams());
        row2.addView(hide, weightParams());
        panel.addView(row2);

        panelParams = new WindowManager.LayoutParams(
                dp(294), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.LEFT;
        panelParams.x = dp(8);
        panelParams.y = dp(60);
        try { wm.addView(panel, panelParams); }
        catch (RuntimeException e) { panel = null; }
        updateButtons();
    }

    private android.graphics.drawable.GradientDrawable makeBackground() {
        android.graphics.drawable.GradientDrawable b = new android.graphics.drawable.GradientDrawable();
        b.setColor(0xEC142331);
        b.setCornerRadius(dp(14));
        b.setStroke(dp(1), 0xFF617D92);
        return b;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(41), 1f);
        p.setMargins(dp(2), dp(4), dp(2), dp(1));
        return p;
    }

    private Button smallButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(11);
        button.setAllCaps(false);
        button.setPadding(0, 0, 0, 0);
        return button;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void updateButtons() {
        if (watchButton != null) watchButton.setText(watch ? "停止识别" : "实时识别");
        if (autoButton != null) autoButton.setText(auto ? "暂停自动" : "自动");
    }

    private void status(String message) {
        if (statusView != null) statusView.setText(message);
    }

    private void toggleWatch() {
        watch = !watch;
        if (!watch) {
            auto = false;
            oneShot = false;
            ui.removeCallbacks(nextCapture);
            status("实时识别已暂停");
        } else {
            status("正在读取棋盘…");
            schedule(50);
        }
        updateButtons();
    }

    private void showCalibration() {
        if (wm == null || calibration != null) return;
        stopAll("正在校准棋盘");
        if (panel != null) panel.setVisibility(View.GONE);
        calibration = new CalibrationView(this, rect -> {
            boardRect = rect;
            getSharedPreferences("board", MODE_PRIVATE).edit()
                    .putInt("left", rect.left).putInt("top", rect.top)
                    .putInt("right", rect.right).putInt("bottom", rect.bottom).apply();
            vision.resetColors();
            previousBoard = null;
            removeCalibration();
            if (panel != null) panel.setVisibility(View.VISIBLE);
            status("已框选棋盘。点击「实时识别」，先核对数字");
        });
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        try { wm.addView(calibration, params); }
        catch (RuntimeException e) {
            calibration = null;
            if (panel != null) panel.setVisibility(View.VISIBLE);
            status("无法显示框选窗口");
        }
    }

    private void removeCalibration() {
        if (calibration == null) return;
        try { wm.removeView(calibration); }
        catch (RuntimeException ignored) { }
        calibration = null;
    }

    private void hidePanel() {
        if (panel != null && wm != null) {
            try { wm.removeView(panel); }
            catch (RuntimeException ignored) { }
        }
        panel = null;
        statusView = null;
        boardView = null;
        bestView = null;
        watchButton = null;
        autoButton = null;
    }

    private void stopAll(String reason) {
        watch = false;
        auto = false;
        oneShot = false;
        awaitingSpawnFrom = null;
        ui.removeCallbacks(nextCapture);
        status(reason);
        updateButtons();
    }

    private void schedule(long delayMs) {
        ui.removeCallbacks(nextCapture);
        if ((watch || auto || oneShot || awaitingSpawnFrom != null)
                && boardRect != null && calibration == null) {
            ui.postDelayed(nextCapture, Math.max(delayMs, 50));
        }
    }

    private void takeBoardScreenshot() {
        if (boardRect == null || busy || performingGesture || calibration != null) return;
        if (!(watch || auto || oneShot || awaitingSpawnFrom != null)) return;
        long elapsed = android.os.SystemClock.uptimeMillis() - lastScreenshotTime;
        if (elapsed < 650) { schedule(650 - elapsed); return; }
        busy = true;
        lastScreenshotTime = android.os.SystemClock.uptimeMillis();
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                @Override public void onSuccess(ScreenshotResult screenshot) {
                    Bitmap copy = null;
                    HardwareBuffer hardware = screenshot.getHardwareBuffer();
                    try {
                        ColorSpace space = screenshot.getColorSpace();
                        Bitmap wrapped = Bitmap.wrapHardwareBuffer(hardware,
                                space != null ? space : ColorSpace.get(ColorSpace.Named.SRGB));
                        if (wrapped == null) throw new IllegalStateException("无法解码屏幕画面");
                        copy = wrapped.copy(Bitmap.Config.ARGB_8888, false);
                        wrapped.recycle();
                        if (copy == null) throw new IllegalStateException("屏幕复制失败");
                    } catch (Exception e) {
                        busy = false;
                        status("截图解析失败：" + e.getMessage());
                        if (auto) stopAll("自动操作已暂停：截图失败");
                        else schedule(1400);
                        return;
                    } finally {
                        hardware.close();
                    }
                    final Bitmap source = copy;
                    vision.read(source, boardRect, (board, error) -> {
                        source.recycle();
                        busy = false;
                        onRecognized(board, error);
                    });
                }

                @Override public void onFailure(int errorCode) {
                    busy = false;
                    if (auto) stopAll("自动操作停止：系统禁止截图（错误" + errorCode + "）");
                    else {
                        status("截图失败：" + errorCode + "。检查无障碍权限和游戏窗口");
                        schedule(1500);
                    }
                }
            });
        } catch (RuntimeException e) {
            busy = false;
            stopAll("截图接口调用失败：" + e.getClass().getSimpleName());
        }
    }

    private void onRecognized(Board board, String error) {
        if (calibration != null) return;
        if (error != null) {
            if (awaitingSpawnFrom != null && ++verificationRetries <= 5) {
                status("等待动画/重新识别（" + verificationRetries + "/5）：" + error);
                schedule(650);
                return;
            }
            if (auto || oneShot || awaitingSpawnFrom != null) {
                stopAll("自动已停止：" + error);
            } else {
                status(error);
                schedule(1100);
            }
            return;
        }
        if (board == null) {
            stopAll("识别结果为空"); return;
        }
        previousBoard = board;
        if (boardView != null) boardView.setText(board.toDisplay());
        Solver.Choice choice = solver.choose(board);
        if (bestView != null) {
            bestView.setText(choice.direction < 0 ? "推荐：无合法移动" :
                    "推荐：" + Board.ARROWS[choice.direction] + "    最大格 " + board.largest());
        }
        if (awaitingSpawnFrom != null) {
            if (!awaitingSpawnFrom.isSingleSpawnFrom(board)) {
                verificationRetries++;
                if (verificationRetries > 5) {
                    stopAll("自动已暂停：棋盘与上一步预测不符（可能有识别误差）");
                    return;
                }
                status("等待新方块/画面稳定（" + verificationRetries + "/5）");
                schedule(650);
                return;
            }
            awaitingSpawnFrom = null;
            verificationRetries = 0;
        }
        status("已识别 · " + moveCount + " 次辅助操作 · 空格 " + board.emptyCount());
        if (choice.direction < 0) {
            stopAll("无合法移动：游戏可能已经结束");
            return;
        }
        if (auto || oneShot) {
            oneShot = false;
            executeMove(board, choice.direction);
        } else {
            schedule(950);
        }
    }

    private void executeMove(Board board, int direction) {
        if (boardRect == null || performingGesture || !isWechatForeground()) {
            stopAll("自动暂停：请先切回微信的2048小程序");
            return;
        }
        Board.Move predicted = board.move(direction);
        if (!predicted.changed) {
            stopAll("推荐移动无效，已停止");
            return;
        }
        int cx = boardRect.centerX();
        int cy = boardRect.centerY();
        int delta = Math.round(boardRect.width() * 0.31f);
        int dx = direction == Board.RIGHT ? delta : direction == Board.LEFT ? -delta : 0;
        int dy = direction == Board.DOWN ? delta : direction == Board.UP ? -delta : 0;
        Path swipe = new Path();
        swipe.moveTo(cx, cy);
        swipe.lineTo(cx + dx, cy + dy);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(swipe, 0, 175));
        performingGesture = true;
        boolean accepted;
        try {
            accepted = dispatchGesture(builder.build(), new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription gestureDescription) {
                    performingGesture = false;
                    awaitingSpawnFrom = predicted.board;
                    verificationRetries = 0;
                    moveCount++;
                    schedule(600);
                }
                @Override public void onCancelled(GestureDescription gestureDescription) {
                    performingGesture = false;
                    stopAll("滑动被系统取消，自动模式已停止");
                }
            }, ui);
        } catch (RuntimeException ex) {
            performingGesture = false;
            stopAll("无法执行滑动：" + ex.getClass().getSimpleName());
            return;
        }
        if (!accepted) {
            performingGesture = false;
            stopAll("无障碍手势被系统拒绝");
        }
    }

    private boolean isWechatForeground() {
        AccessibilityNodeInfo node = getRootInActiveWindow();
        if (node == null) return false;
        CharSequence pkg = node.getPackageName();
        return pkg != null && "com.tencent.mm".contentEquals(pkg);
    }

    private int dp(float n) { return Math.round(n * getResources().getDisplayMetrics().density); }
}
