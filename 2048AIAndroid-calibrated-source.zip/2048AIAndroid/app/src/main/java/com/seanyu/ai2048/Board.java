package com.seanyu.ai2048;

import java.util.Arrays;

/** Immutable 4x4 board, row-major values 0 or powers of two. Pure Java. */
public final class Board {
    public final int[] cells;

    public Board(int[] cells) {
        if (cells == null || cells.length != 16) throw new IllegalArgumentException("16 cells required");
        this.cells = cells.clone();
        for (int n : cells) {
            if (n < 0 || (n != 0 && (n & (n - 1)) != 0)) {
                throw new IllegalArgumentException("Bad tile: " + n);
            }
        }
    }

    public static final int UP = 0, RIGHT = 1, DOWN = 2, LEFT = 3;
    public static final String[] ARROWS = {"↑ 上", "→ 右", "↓ 下", "← 左"};

    public static final class Move {
        public final Board board;
        public final boolean changed;
        public final int gained;
        Move(Board board, boolean changed, int gained) {
            this.board = board;
            this.changed = changed;
            this.gained = gained;
        }
    }

    public Move move(int direction) {
        if (direction < 0 || direction > 3) throw new IllegalArgumentException("bad direction");
        int[] result = cells.clone();
        int gained = 0;
        for (int line = 0; line < 4; line++) {
            int[] old = new int[4];
            for (int pos = 0; pos < 4; pos++) old[pos] = cells[index(direction, line, pos)];
            int[] ordered = new int[4];
            int count = 0;
            for (int n : old) if (n != 0) ordered[count++] = n;
            int[] merged = new int[4];
            int at = 0;
            for (int pos = 0; pos < count; pos++) {
                if (pos + 1 < count && ordered[pos] == ordered[pos + 1]) {
                    merged[at++] = ordered[pos] * 2;
                    gained += ordered[pos] * 2;
                    pos++;
                } else {
                    merged[at++] = ordered[pos];
                }
            }
            for (int pos = 0; pos < 4; pos++) result[index(direction, line, pos)] = merged[pos];
        }
        return new Move(new Board(result), !Arrays.equals(cells, result), gained);
    }

    private static int index(int direction, int line, int pos) {
        switch (direction) {
            case UP: return pos * 4 + line;
            case RIGHT: return line * 4 + (3 - pos);
            case DOWN: return (3 - pos) * 4 + line;
            default: return line * 4 + pos;
        }
    }

    public int emptyCount() {
        int n = 0;
        for (int x : cells) if (x == 0) n++;
        return n;
    }

    /** After an action the normal game must add EXACTLY one 2/4 in an empty square. */
    public boolean isSingleSpawnFrom(Board afterSwipe) {
        int extras = 0;
        for (int i = 0; i < 16; i++) {
            if (cells[i] == afterSwipe.cells[i]) continue;
            if (cells[i] == 0 && (afterSwipe.cells[i] == 2 || afterSwipe.cells[i] == 4)) extras++;
            else return false;
        }
        return extras == 1;
    }

    public int largest() {
        int max = 0;
        for (int x : cells) max = Math.max(max, x);
        return max;
    }

    public String toDisplay() {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < 16; i++) {
            s.append(String.format(java.util.Locale.ROOT, "%5s", cells[i] == 0 ? "·" : Integer.toString(cells[i])));
            if (i % 4 == 3) s.append('\n');
        }
        return s.toString();
    }
}
