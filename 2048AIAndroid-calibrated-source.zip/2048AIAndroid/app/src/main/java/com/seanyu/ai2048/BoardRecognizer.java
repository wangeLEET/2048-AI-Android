package com.seanyu.ai2048;

import android.graphics.Bitmap;
import android.graphics.Rect;

import java.util.Arrays;

/** Recognizes the user's specific 2048 skin from calibrated tile background colors. */
public final class BoardRecognizer {
    public interface Callback {
        void complete(Board board, String error);
    }

    public void resetColors() { /* Fixed palette already calibrated from supplied screenshots. */ }
    public void close() { /* No external OCR model or resources to release. */ }

    public void read(Bitmap screenshot, Rect rect, Callback callback) {
        if (rect == null || rect.left < 0 || rect.top < 0
                || rect.right > screenshot.getWidth() || rect.bottom > screenshot.getHeight()
                || rect.width() < 140 || rect.height() < 140) {
            callback.complete(null, "请框选完整的4×4棋盘（包含外边框）");
            return;
        }
        // Sample four patches per tile, keeping safely clear of large centered digits.
        // The sample points are proportional to the selected grid rectangle.
        int[] values = new int[16];
        float[][] points = {{.20f, .20f}, {.80f, .20f}, {.20f, .80f}, {.80f, .80f}};
        int[] colors = new int[4];
        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {
                int index = row * 4 + col;
                for (int p = 0; p < 4; p++) {
                    int px = rect.left + Math.round(rect.width() * (col + points[p][0]) / 4f);
                    int py = rect.top + Math.round(rect.height() * (row + points[p][1]) / 4f);
                    colors[p] = screenshot.getPixel(
                            Math.min(screenshot.getWidth() - 1, px),
                            Math.min(screenshot.getHeight() - 1, py));
                }
                // Median of corner colors tolerates a stray anti-aliased numeral edge.
                int r = median4((colors[0] >> 16) & 255, (colors[1] >> 16) & 255,
                        (colors[2] >> 16) & 255, (colors[3] >> 16) & 255);
                int g = median4((colors[0] >> 8) & 255, (colors[1] >> 8) & 255,
                        (colors[2] >> 8) & 255, (colors[3] >> 8) & 255);
                int b = median4(colors[0] & 255, colors[1] & 255,
                        colors[2] & 255, colors[3] & 255);
                int value = TilePalette.decode(r, g, b);
                if (value < 0) {
                    callback.complete(null, "第" + (row + 1) + "行第" + (col + 1)
                            + "列颜色不在已知图块中。请重新框选，或暂停手动处理新颜色。");
                    return;
                }
                values[index] = value;
            }
        }
        try {
            callback.complete(new Board(values), null);
        } catch (IllegalArgumentException ex) {
            callback.complete(null, "识别的棋盘数字不符合2048规则");
        }
    }

    private static int median4(int a, int b, int c, int d) {
        int[] v = {a, b, c, d};
        Arrays.sort(v);
        return (v[1] + v[2]) / 2;
    }
}
