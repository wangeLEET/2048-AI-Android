import com.seanyu.ai2048.Board;
import com.seanyu.ai2048.Solver;
import java.util.Arrays;

public class SolverSelfTest {
    private static void eq(int[] actual, int[] expected, String label) {
        if (!Arrays.equals(actual, expected)) throw new AssertionError(label + ": " + Arrays.toString(actual));
    }
    public static void main(String[] args) {
        Board base = new Board(new int[]{2,2,2,2, 4,0,4,0, 0,0,0,0, 0,0,0,0});
        eq(base.move(Board.LEFT).board.cells, new int[]{4,4,0,0,8,0,0,0,0,0,0,0,0,0,0,0}, "LEFT merges once");
        eq(base.move(Board.RIGHT).board.cells, new int[]{0,0,4,4,0,0,0,8,0,0,0,0,0,0,0,0}, "RIGHT merges once");
        Board sample = new Board(new int[]{2,0,0,0,0,0,0,0,8,0,0,0,16,0,0,0});
        Board.Move down = sample.move(Board.DOWN);
        eq(down.board.cells, new int[]{0,0,0,0,2,0,0,0,8,0,0,0,16,0,0,0}, "DOWN ordering");
        // The DOWN expected result above should be [0,2,4,8] in column 0 from row top to bottom.
        Board b = new Board(new int[]{2,4,8,16,32,64,128,256,512,1024,2,4,8,16,32,64});
        if (new Solver().choose(b).direction != -1) throw new AssertionError("Game over detection");
        Board expected = base.move(Board.LEFT).board;
        int[] spawned = expected.cells.clone(); spawned[15] = 2;
        if (!expected.isSingleSpawnFrom(new Board(spawned))) throw new AssertionError("Spawn verification");
        if (expected.isSingleSpawnFrom(expected)) throw new AssertionError("Zero-spawn should fail");
        long start = System.nanoTime();
        for (int i=0; i<3; i++) {
            Solver.Choice choice = new Solver().choose(base);
            if (choice.direction < 0) throw new AssertionError("No recommendation");
        }
        System.out.printf("OK. Three solver calls: %.0f ms%n", (System.nanoTime()-start)/1e6);
    }
}
