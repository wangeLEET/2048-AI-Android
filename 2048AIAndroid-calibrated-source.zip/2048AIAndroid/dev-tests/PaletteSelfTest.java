import com.seanyu.ai2048.TilePalette;

public class PaletteSelfTest {
    public static void main(String[] args) {
        int[][] reference = {
                {0, 202,190,178}, {2,238,228,218}, {4,235,220,197},
                {8,245,178,125}, {16,246,150,100}, {32,247,127,93},
                {64,246,91,60}, {128,237,206,115}, {256,236,202,95},
                {512,238,199,80}, {1024,237,197,65}, {2048,238,193,48},
                {4096,255,61,62}
        };
        for (int[] v: reference) {
            int actual = TilePalette.decode(v[1], v[2], v[3]);
            if (actual != v[0]) throw new AssertionError(v[0] + " became " + actual);
        }
        // A few near-identical red samples from JPEG compression should still decode.
        if (TilePalette.decode(254, 60, 64) != 4096) {
            throw new AssertionError("nearby red should decode as 4096");
        }
        // 32 and 64 are also warm colors: adding 4096 must not regress them.
        if (TilePalette.decode(247,127,93) != 32 || TilePalette.decode(246,91,60) != 64) {
            throw new AssertionError("older red/orange tiles were confused with 4096");
        }
        if (TilePalette.decode(0,0,0) != -1) throw new AssertionError("unknown should be rejected");
        System.out.println("PASS: all calibrated tiles including 4096, neighboring colors, and unknown rejection");
    }
}
